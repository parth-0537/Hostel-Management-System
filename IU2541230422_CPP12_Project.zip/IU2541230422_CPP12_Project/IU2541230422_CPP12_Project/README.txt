===========================================
HOSTEL ROOM ALLOCATION SYSTEM
=============================

Student Information:
Enrollment Number : IU2541230422
Project Code      : CPP12
Project Name      : Hostel Room Allocation System

============================================
PROJECT DESCRIPTION
===================

A console-based Hostel Room Allocation System built in C++
demonstrating core OOP concepts including classes, encapsulation,
inheritance, runtime polymorphism, dynamic memory management,
file handling, and exception handling.

============================================
FOLDER STRUCTURE
================

Source/       - All .h and .cpp source files
Data/         - Data files (rooms.txt, students.txt, wardens.txt, allocations.txt)
Diagrams/     - UML diagrams (UseCaseDiagram, ClassDiagram, SequenceDiagram1, SequenceDiagram2)
Executable/   - Compiled executable (Project.exe)
Screenshots/  - Program screenshots
README.txt    - This file
ProjectReport.pdf - Project report

============================================
HOW TO COMPILE
==============

Using Command Prompt (CMD):

1. Open CMD in the project root directory.

2. Compile the source files using:

   g++ -std=c++11 -o Executable\Project.exe Source*.cpp

3. Run the program using:

   Executable\Project.exe

============================================
HOW TO USE
==========

1. Run the executable from the project root directory.
2. The system loads saved data if available.
3. Use the menu to:

   * Add/Display/Search/Update/Delete rooms, students, and wardens
   * Manage hostel room allocations
   * Allocate, vacate, and transfer rooms
   * Generate reports
   * Save/Load data
4. Data is automatically saved when you exit.

============================================
CLASSES
=======

1. Person      - Base class for students and wardens
2. Student     - Stores student information
3. Warden      - Stores warden information
4. Room        - Manages hostel room details
5. Allocation  - Manages room allocation records
6. Hostel      - Main system class managing hostel operations
7. FileManager - Handles file input and output

============================================
OOP CONCEPTS DEMONSTRATED
=========================

* Classes and Objects
* Encapsulation (private data, public interface)
* Constructors and Destructors
* Inheritance
* Runtime Polymorphism
* Dynamic Memory Management
* File Handling (saving/loading text files)
* Exception Handling
* Input Validation

============================================
DATA FILES
==========

All data is stored in the Data/ folder:

* rooms.txt       : Room records
* students.txt    : Student records
* wardens.txt     : Warden records
* allocations.txt : Room allocation records

# Files use pipe '|' as delimiter.
