// Room.cpp
#include "Room.h"

#include <iomanip>
#include <iostream>
#include <sstream>

#include "Utils.h"

Room::Room() : roomNo(0), floor(0), capacity(1), occupied(0), fee(1000.0) {}

Room::Room(int rno, int rfloor, int rcap, double rfee, int rocc)
    : roomNo(0), floor(0), capacity(1), occupied(0), fee(1000.0) {
    if (rno < 1 || rno > 9999) throw HostelException("Room number must be between 1 and 9999.");
    roomNo = rno;
    setFloor(rfloor);
    setCapacity(rcap);
    setFee(rfee);
    if (rocc < 0 || rocc > capacity) throw HostelException("Occupancy must be between 0 and capacity.");
    occupied = rocc;
}

Room::~Room() {}

void Room::setFloor(int f) {
    if (f < 0 || f > 20) throw HostelException("Floor must be between 0 and 20.");
    floor = f;
}

void Room::setCapacity(int c) {
    if (c < 1 || c > 4) throw HostelException("Capacity must be between 1 and 4.");
    if (c < occupied) throw HostelException("Capacity cannot be less than current occupancy.");
    capacity = c;
}

void Room::setFee(double f) {
    if (f <= 0 || f > 100000) throw HostelException("Fee must be between 1 and 100000.");
    fee = f;
}

void Room::occupy() {
    if (isFull()) throw HostelException("Room " + std::to_string(roomNo) + " is already full.");
    ++occupied;
}

void Room::vacate() {
    if (occupied <= 0) throw HostelException("Room " + std::to_string(roomNo) + " is already empty.");
    --occupied;
}

std::string Room::typeName() const {
    if (capacity == 1) return "Single";
    if (capacity == 2) return "Double";
    if (capacity == 3) return "Triple";
    return "Quad";
}

void Room::display() const {
    std::cout << std::left << std::setw(7) << roomNo << std::setw(7) << floor << std::setw(9) << typeName()
              << std::setw(10) << capacity << std::setw(10) << occupied << std::fixed << std::setprecision(2)
              << std::setw(10) << fee << (isFull() ? "FULL" : "Available") << "\n";
}

std::string Room::serialize() const {
    std::ostringstream os;
    os << roomNo << '|' << floor << '|' << capacity << '|' << fee << '|' << occupied;
    return os.str();
}

void Room::fromString(const std::string& line) {
    std::string f[6];
    if (splitLine(line, '|', f, 5) != 5) throw HostelException("Malformed room record: " + line);
    *this = Room(toInt(f[0]), toInt(f[1]), toInt(f[2]), toDouble(f[3]), toInt(f[4]));
}
