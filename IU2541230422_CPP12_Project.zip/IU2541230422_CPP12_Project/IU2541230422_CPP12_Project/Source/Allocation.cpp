// Allocation.cpp
#include "Allocation.h"

#include <iomanip>
#include <iostream>
#include <sstream>

#include "Utils.h"

Allocation::Allocation() : allocId(0), studentId(0), roomNo(0), startDate("-"), endDate("-") {}

Allocation::Allocation(int aid, int sid, int rno, const std::string& start, const std::string& end)
    : allocId(aid), studentId(sid), roomNo(rno), startDate(start), endDate(end) {
    if (aid <= 0 || sid <= 0 || rno <= 0) throw HostelException("Invalid allocation identifiers.");
    if (start.empty() || end.empty() || start.find('|') != std::string::npos ||
        end.find('|') != std::string::npos)
        throw HostelException("Invalid allocation dates.");
}

Allocation::~Allocation() {}

void Allocation::close(const std::string& date) {
    if (!isActive()) throw HostelException("Allocation already closed.");
    endDate = date;
}

void Allocation::display() const {
    std::cout << std::left << std::setw(8) << allocId << std::setw(10) << studentId << std::setw(8) << roomNo
              << std::setw(13) << startDate << std::setw(13) << endDate << (isActive() ? "ACTIVE" : "Closed")
              << "\n";
}

std::string Allocation::serialize() const {
    std::ostringstream os;
    os << allocId << '|' << studentId << '|' << roomNo << '|' << startDate << '|' << endDate;
    return os.str();
}

void Allocation::fromString(const std::string& line) {
    std::string f[6];
    if (splitLine(line, '|', f, 5) != 5) throw HostelException("Malformed allocation record: " + line);
    *this = Allocation(toInt(f[0]), toInt(f[1]), toInt(f[2]), f[3], f[4]);
}
