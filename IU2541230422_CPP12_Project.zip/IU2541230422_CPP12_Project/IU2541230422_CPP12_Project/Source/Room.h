// Room.h - a hostel room with limited capacity
#ifndef ROOM_H
#define ROOM_H

#include <string>

class Room {
    int roomNo;
    int floor;
    int capacity;   // 1..4 beds
    int occupied;   // beds currently taken
    double fee;     // monthly fee per bed

public:
    Room();
    Room(int roomNo, int floor, int capacity, double fee, int occupied = 0);
    ~Room();

    int getRoomNo() const { return roomNo; }
    int getFloor() const { return floor; }
    int getCapacity() const { return capacity; }
    int getOccupied() const { return occupied; }
    double getFee() const { return fee; }
    int vacancies() const { return capacity - occupied; }
    bool isFull() const { return occupied >= capacity; }
    std::string typeName() const;   // Single / Double / Triple / Quad

    void setFloor(int f);
    void setCapacity(int c);        // cannot drop below current occupancy
    void setFee(double f);
    void occupy();                  // throws if full
    void vacate();                  // throws if empty

    void display() const;
    std::string serialize() const;
    void fromString(const std::string& line);   // rebuilds this object from a file line
};

#endif
