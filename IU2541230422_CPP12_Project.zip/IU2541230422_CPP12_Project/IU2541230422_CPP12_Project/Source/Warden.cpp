// Warden.cpp
#include "Warden.h"

#include <iomanip>
#include <iostream>
#include <sstream>

#include "Utils.h"

Warden::Warden() : Person(), block("A"), shift("Day") {}

Warden::Warden(int wid, const std::string& wname, const std::string& wphone,
               const std::string& wblock, const std::string& wshift)
    : Person(wid, wname, wphone), block("A"), shift("Day") {
    setBlock(wblock);
    setShift(wshift);
}

Warden::~Warden() {}

void Warden::setBlock(const std::string& b) {
    if (!isValidText(b) || b.size() > 5) throw HostelException("Block must be 1-5 characters (e.g. A).");
    block = b;
}

void Warden::setShift(const std::string& s) {
    std::string l = toLower(s);
    if (l == "day") shift = "Day";
    else if (l == "evening") shift = "Evening";
    else if (l == "night") shift = "Night";
    else throw HostelException("Shift must be Day, Evening or Night.");
}

void Warden::display() const {
    std::cout << std::left << std::setw(9) << "Warden" << std::setw(8) << id << std::setw(22) << name
              << std::setw(13) << phone << std::setw(14) << ("Block " + block) << shift << " shift\n";
}

std::string Warden::serialize() const {
    std::ostringstream os;
    os << id << '|' << name << '|' << phone << '|' << block << '|' << shift;
    return os.str();
}

void Warden::fromString(const std::string& line) {
    std::string f[6];
    if (splitLine(line, '|', f, 5) != 5) throw HostelException("Malformed warden record: " + line);
    *this = Warden(toInt(f[0]), f[1], f[2], f[3], f[4]);
}
