// Hostel.cpp - business logic for the Hostel Room Allocation System
#include "Hostel.h"

#include <iomanip>
#include <iostream>
#include <sstream>

#include "Utils.h"

using std::cout;

void roomHeader() {
    cout << std::left << std::setw(7) << "Room" << std::setw(7) << "Floor" << std::setw(9) << "Type"
         << std::setw(10) << "Capacity" << std::setw(10) << "Occupied" << std::setw(10) << "Fee" << "Status\n"
         << std::string(63, '-') << "\n";
}
void personHeader() {
    cout << std::left << std::setw(9) << "Role" << std::setw(8) << "ID" << std::setw(22) << "Name"
         << std::setw(13) << "Phone" << std::setw(14) << "Course/Block" << "Details\n"
         << std::string(80, '-') << "\n";
}
void allocHeader() {
    cout << std::left << std::setw(8) << "AllocID" << std::setw(10) << "Student" << std::setw(8) << "Room"
         << std::setw(13) << "Start" << std::setw(13) << "End" << "Status\n"
         << std::string(60, '-') << "\n";
}

Hostel::Hostel(const std::string& hostelName, const std::string& dataDir)
    : name(hostelName), fileManager(dataDir), nextAllocId(1) {
    roomCap = 8;    rooms = new Room[roomCap];                 roomCount = 0;
    studentCap = 8; students = new Student[studentCap];        studentCount = 0;
    wardenCap = 4;  wardens = new Warden[wardenCap];           wardenCount = 0;
    allocCap = 8;   allocations = new Allocation[allocCap];    allocCount = 0;
}

Hostel::~Hostel() {
    delete[] rooms;
    delete[] students;
    delete[] wardens;
    delete[] allocations;
}

// ------------------------------------------------------------------ dynamic array helpers
void Hostel::addRoomObj(const Room& r) {
    if (roomCount == roomCap) {               // full: allocate a bigger block, copy, free the old one
        Room* bigger = new Room[roomCap * 2];
        for (int i = 0; i < roomCount; ++i) bigger[i] = rooms[i];
        delete[] rooms;
        rooms = bigger;
        roomCap *= 2;
    }
    rooms[roomCount++] = r;
}
void Hostel::addStudentObj(const Student& s) {
    if (studentCount == studentCap) {
        Student* bigger = new Student[studentCap * 2];
        for (int i = 0; i < studentCount; ++i) bigger[i] = students[i];
        delete[] students;
        students = bigger;
        studentCap *= 2;
    }
    students[studentCount++] = s;
}
void Hostel::addWardenObj(const Warden& w) {
    if (wardenCount == wardenCap) {
        Warden* bigger = new Warden[wardenCap * 2];
        for (int i = 0; i < wardenCount; ++i) bigger[i] = wardens[i];
        delete[] wardens;
        wardens = bigger;
        wardenCap *= 2;
    }
    wardens[wardenCount++] = w;
}
void Hostel::addAllocObj(const Allocation& a) {
    if (allocCount == allocCap) {
        Allocation* bigger = new Allocation[allocCap * 2];
        for (int i = 0; i < allocCount; ++i) bigger[i] = allocations[i];
        delete[] allocations;
        allocations = bigger;
        allocCap *= 2;
    }
    allocations[allocCount++] = a;
}
void Hostel::removeRoomAt(int index) {
    for (int i = index; i < roomCount - 1; ++i) rooms[i] = rooms[i + 1];
    --roomCount;
}
void Hostel::removeStudentAt(int index) {
    for (int i = index; i < studentCount - 1; ++i) students[i] = students[i + 1];
    --studentCount;
}
void Hostel::removeWardenAt(int index) {
    for (int i = index; i < wardenCount - 1; ++i) wardens[i] = wardens[i + 1];
    --wardenCount;
}

// ------------------------------------------------------------------ lookups
int Hostel::findRoom(int roomNo) const {
    for (int i = 0; i < roomCount; ++i)
        if (rooms[i].getRoomNo() == roomNo) return i;
    return -1;
}
int Hostel::findStudent(int id) const {
    for (int i = 0; i < studentCount; ++i)
        if (students[i].getId() == id) return i;
    return -1;
}
int Hostel::findWarden(int id) const {
    for (int i = 0; i < wardenCount; ++i)
        if (wardens[i].getId() == id) return i;
    return -1;
}
int Hostel::findActiveAllocation(int studentId) const {
    for (int i = 0; i < allocCount; ++i)
        if (allocations[i].getStudentId() == studentId && allocations[i].isActive()) return i;
    return -1;
}
bool Hostel::idInUse(int id) const { return findStudent(id) != -1 || findWarden(id) != -1; }

// ------------------------------------------------------------------ 1. ADD
void Hostel::addRecord() {
    cout << "\n--- ADD RECORD ---\n1. Room\n2. Student\n3. Warden\n0. Back\n";
    int c = readInt("Choice: ", 0, 3);
    try {
        if (c == 1) addRoom();
        else if (c == 2) addStudent();
        else if (c == 3) addWarden();
    } catch (const HostelException& e) {
        cout << "  Error: " << e.what() << "\n";
    }
}

void Hostel::addRoom() {
    int no = readInt("Room number (1-9999): ", 1, 9999);
    if (findRoom(no) != -1) throw HostelException("Room " + std::to_string(no) + " already exists.");
    int floor = readInt("Floor (0-20): ", 0, 20);
    int cap = readInt("Capacity / beds (1-4): ", 1, 4);
    double fee = readDouble("Monthly fee per bed: ", 1, 100000);
    addRoomObj(Room(no, floor, cap, fee));
    cout << "  Room " << no << " added.\n";
}

void Hostel::addStudent() {
    int id = readInt("Student ID (1-999999): ", 1, 999999);
    if (idInUse(id)) throw HostelException("ID " + std::to_string(id) + " is already in use.");
    std::string nm = readLine("Name: ");
    std::string ph = readLine("Phone (10 digits): ");
    std::string course = readLine("Course: ");
    int year = readInt("Year (1-6): ", 1, 6);
    addStudentObj(Student(id, nm, ph, course, year));   // constructor validates every field
    cout << "  Student " << id << " added.\n";
}

void Hostel::addWarden() {
    int id = readInt("Warden ID (1-999999): ", 1, 999999);
    if (idInUse(id)) throw HostelException("ID " + std::to_string(id) + " is already in use.");
    std::string nm = readLine("Name: ");
    std::string ph = readLine("Phone (10 digits): ");
    std::string block = readLine("Block (e.g. A): ");
    std::string shift = readLine("Shift (Day/Evening/Night): ");
    addWardenObj(Warden(id, nm, ph, block, shift));
    cout << "  Warden " << id << " added.\n";
}

// ------------------------------------------------------------------ 2. DISPLAY
void Hostel::displayRecords() {
    cout << "\n--- DISPLAY RECORDS ---\n1. Rooms\n2. Students\n3. Wardens\n4. Allocations\n"
            "5. All people (Students + Wardens)\n0. Back\n";
    int c = readInt("Choice: ", 0, 5);
    switch (c) {
        case 1: displayRooms(); break;
        case 2: displayStudents(); break;
        case 3: displayWardens(); break;
        case 4: displayAllocations(); break;
        case 5: displayAllPeople(); break;
        default: break;
    }
}

void Hostel::displayRooms() const {
    cout << "\n";
    if (roomCount == 0) { cout << "  No rooms recorded.\n"; return; }
    roomHeader();
    for (int i = 0; i < roomCount; ++i) rooms[i].display();
}
void Hostel::displayStudents() const {
    cout << "\n";
    if (studentCount == 0) { cout << "  No students recorded.\n"; return; }
    personHeader();
    for (int i = 0; i < studentCount; ++i) students[i].display();
}
void Hostel::displayWardens() const {
    cout << "\n";
    if (wardenCount == 0) { cout << "  No wardens recorded.\n"; return; }
    personHeader();
    for (int i = 0; i < wardenCount; ++i) wardens[i].display();
}
void Hostel::displayAllocations() const {
    cout << "\n";
    if (allocCount == 0) { cout << "  No allocations recorded.\n"; return; }
    allocHeader();
    for (int i = 0; i < allocCount; ++i) allocations[i].display();
}

// Runtime polymorphism: one Person* array holds both Students and Wardens;
// display() is resolved at run time to the correct derived-class version.
void Hostel::displayAllPeople() const {
    int total = studentCount + wardenCount;
    cout << "\n";
    if (total == 0) { cout << "  No people recorded.\n"; return; }
    const Person** people = new const Person*[total];   // dynamic array of base pointers
    int n = 0;
    for (int i = 0; i < studentCount; ++i) people[n++] = &students[i];
    for (int i = 0; i < wardenCount; ++i) people[n++] = &wardens[i];
    personHeader();
    for (int i = 0; i < n; ++i) people[i]->display();   // virtual call
    cout << "  (" << studentCount << " students, " << wardenCount << " wardens)\n";
    delete[] people;
}

// ------------------------------------------------------------------ 3. SEARCH
void Hostel::searchRecord() {
    cout << "\n--- SEARCH RECORD ---\n1. Room by number\n2. Student by ID\n3. Student by name\n"
            "4. Warden by ID\n0. Back\n";
    int c = readInt("Choice: ", 0, 4);
    switch (c) {
        case 1: searchRoom(); break;
        case 2: searchStudentById(); break;
        case 3: searchStudentByName(); break;
        case 4: searchWarden(); break;
        default: break;
    }
}

void Hostel::searchRoom() const {
    int no = readInt("Room number: ", 1, 9999);
    int i = findRoom(no);
    if (i == -1) { cout << "  Room not found.\n"; return; }
    cout << "\n";
    roomHeader();
    rooms[i].display();
    bool any = false;
    for (int s = 0; s < studentCount; ++s)
        if (students[s].getRoomNo() == no) {
            if (!any) cout << "  Residents:\n";
            any = true;
            cout << "    - " << students[s].getName() << " (ID " << students[s].getId() << ")\n";
        }
}

void Hostel::searchStudentById() const {
    int id = readInt("Student ID: ", 1, 999999);
    int i = findStudent(id);
    if (i == -1) { cout << "  Student not found.\n"; return; }
    cout << "\n";
    personHeader();
    students[i].display();
}

void Hostel::searchStudentByName() const {
    std::string key = toLower(readLine("Name (or part of it): "));
    if (key.empty()) { cout << "  Nothing to search for.\n"; return; }
    int found = 0;
    for (int i = 0; i < studentCount; ++i) {
        if (toLower(students[i].getName()).find(key) == std::string::npos) continue;
        if (found == 0) { cout << "\n"; personHeader(); }
        students[i].display();
        ++found;
    }
    if (found == 0) cout << "  No matching students.\n";
}

void Hostel::searchWarden() const {
    int id = readInt("Warden ID: ", 1, 999999);
    int i = findWarden(id);
    if (i == -1) { cout << "  Warden not found.\n"; return; }
    cout << "\n";
    personHeader();
    wardens[i].display();
}

// ------------------------------------------------------------------ 4. UPDATE
void Hostel::updateRecord() {
    cout << "\n--- UPDATE RECORD ---\n1. Room\n2. Student\n3. Warden\n0. Back\n";
    int c = readInt("Choice: ", 0, 3);
    try {
        if (c == 1) updateRoom();
        else if (c == 2) updateStudent();
        else if (c == 3) updateWarden();
    } catch (const HostelException& e) {
        cout << "  Error: " << e.what() << "  (no changes saved)\n";
    }
}

void Hostel::updateRoom() {
    int no = readInt("Room number to update: ", 1, 9999);
    int i = findRoom(no);
    if (i == -1) throw HostelException("Room not found.");
    Room copy = rooms[i];   // edit a copy so a failed validation changes nothing
    cout << "  Leave a field blank to keep its current value.\n";
    std::string s = readLine("Floor [" + std::to_string(copy.getFloor()) + "]: ");
    if (!s.empty()) copy.setFloor(toInt(s));
    s = readLine("Capacity [" + std::to_string(copy.getCapacity()) + "]: ");
    if (!s.empty()) copy.setCapacity(toInt(s));
    s = readLine("Fee [" + std::to_string((int)copy.getFee()) + "]: ");
    if (!s.empty()) copy.setFee(toDouble(s));
    rooms[i] = copy;
    cout << "  Room " << no << " updated.\n";
}

void Hostel::updateStudent() {
    int id = readInt("Student ID to update: ", 1, 999999);
    int i = findStudent(id);
    if (i == -1) throw HostelException("Student not found.");
    Student copy = students[i];
    cout << "  Leave a field blank to keep its current value.\n";
    std::string s = readLine("Name [" + copy.getName() + "]: ");
    if (!s.empty()) copy.setName(s);
    s = readLine("Phone [" + copy.getPhone() + "]: ");
    if (!s.empty()) copy.setPhone(s);
    s = readLine("Course [" + copy.getCourse() + "]: ");
    if (!s.empty()) copy.setCourse(s);
    s = readLine("Year [" + std::to_string(copy.getYear()) + "]: ");
    if (!s.empty()) copy.setYear(toInt(s));
    students[i] = copy;
    cout << "  Student " << id << " updated.\n";
}

void Hostel::updateWarden() {
    int id = readInt("Warden ID to update: ", 1, 999999);
    int i = findWarden(id);
    if (i == -1) throw HostelException("Warden not found.");
    Warden copy = wardens[i];
    cout << "  Leave a field blank to keep its current value.\n";
    std::string s = readLine("Name [" + copy.getName() + "]: ");
    if (!s.empty()) copy.setName(s);
    s = readLine("Phone [" + copy.getPhone() + "]: ");
    if (!s.empty()) copy.setPhone(s);
    s = readLine("Block [" + copy.getBlock() + "]: ");
    if (!s.empty()) copy.setBlock(s);
    s = readLine("Shift [" + copy.getShift() + "]: ");
    if (!s.empty()) copy.setShift(s);
    wardens[i] = copy;
    cout << "  Warden " << id << " updated.\n";
}

// ------------------------------------------------------------------ 5. DELETE
void Hostel::deleteRecord() {
    cout << "\n--- DELETE RECORD ---\n1. Room\n2. Student\n3. Warden\n0. Back\n";
    int c = readInt("Choice: ", 0, 3);
    try {
        if (c == 1) deleteRoom();
        else if (c == 2) deleteStudent();
        else if (c == 3) deleteWarden();
    } catch (const HostelException& e) {
        cout << "  Error: " << e.what() << "\n";
    }
}

void Hostel::deleteRoom() {
    int no = readInt("Room number to delete: ", 1, 9999);
    int i = findRoom(no);
    if (i == -1) throw HostelException("Room not found.");
    if (rooms[i].getOccupied() > 0)
        throw HostelException("Room " + std::to_string(no) + " has residents. Vacate them first.");
    if (!confirm("Delete room " + std::to_string(no) + "?")) { cout << "  Cancelled.\n"; return; }
    removeRoomAt(i);
    cout << "  Room deleted.\n";
}

void Hostel::deleteStudent() {
    int id = readInt("Student ID to delete: ", 1, 999999);
    int i = findStudent(id);
    if (i == -1) throw HostelException("Student not found.");
    std::string msg = "Delete student " + students[i].getName() + "?";
    if (students[i].hasRoom()) msg += " Their room will be vacated.";
    if (!confirm(msg)) { cout << "  Cancelled.\n"; return; }
    if (students[i].hasRoom()) doVacate(i);
    removeStudentAt(i);
    cout << "  Student deleted.\n";
}

void Hostel::deleteWarden() {
    int id = readInt("Warden ID to delete: ", 1, 999999);
    int i = findWarden(id);
    if (i == -1) throw HostelException("Warden not found.");
    if (!confirm("Delete warden " + wardens[i].getName() + "?")) { cout << "  Cancelled.\n"; return; }
    removeWardenAt(i);
    cout << "  Warden deleted.\n";
}

// ------------------------------------------------------------------ 6. MAIN TRANSACTION
void Hostel::mainTransaction() {
    cout << "\n--- ROOM ALLOCATION (MAIN TRANSACTION) ---\n1. Allocate a room to a student\n"
            "2. Vacate a student's room\n3. Transfer student to another room\n0. Back\n";
    int c = readInt("Choice: ", 0, 3);
    try {
        if (c == 1) allocateRoom();
        else if (c == 2) vacateRoom();
        else if (c == 3) transferStudent();
    } catch (const HostelException& e) {
        cout << "  Error: " << e.what() << "\n";
    }
}

void Hostel::listVacantRooms() const {
    int shown = 0;
    for (int i = 0; i < roomCount; ++i) {
        if (rooms[i].isFull()) continue;
        if (shown == 0) { cout << "\n  Vacant rooms:\n"; roomHeader(); }
        rooms[i].display();
        ++shown;
    }
    if (shown == 0) cout << "  (No vacant rooms)\n";
}

void Hostel::doAllocate(int studentIdx, int roomIdx) {
    Student& st = students[studentIdx];
    Room& rm = rooms[roomIdx];
    rm.occupy();   // throws if full - nothing else has changed yet
    try {
        addAllocObj(Allocation(nextAllocId, st.getId(), rm.getRoomNo(), today()));
    } catch (...) {
        rm.vacate();   // roll back
        throw;
    }
    ++nextAllocId;
    st.setRoomNo(rm.getRoomNo());
}

void Hostel::doVacate(int studentIdx) {
    Student& st = students[studentIdx];
    int a = findActiveAllocation(st.getId());
    int r = findRoom(st.getRoomNo());
    if (a != -1) allocations[a].close(today());
    if (r != -1) rooms[r].vacate();
    st.setRoomNo(-1);
}

void Hostel::allocateRoom() {
    int sid = readInt("Student ID: ", 1, 999999);
    int si = findStudent(sid);
    if (si == -1) throw HostelException("Student not found.");
    if (students[si].hasRoom())
        throw HostelException(students[si].getName() + " already has room " +
                              std::to_string(students[si].getRoomNo()) + ".");
    listVacantRooms();
    if (roomCount == 0) throw HostelException("No rooms exist. Add rooms first.");
    int rno = readInt("Room number to allocate: ", 1, 9999);
    int ri = findRoom(rno);
    if (ri == -1) throw HostelException("Room not found.");
    doAllocate(si, ri);
    cout << "  Allocated room " << rno << " to " << students[si].getName() << " (allocation #"
         << (nextAllocId - 1) << ").\n";
}

void Hostel::vacateRoom() {
    int sid = readInt("Student ID: ", 1, 999999);
    int si = findStudent(sid);
    if (si == -1) throw HostelException("Student not found.");
    if (!students[si].hasRoom()) throw HostelException(students[si].getName() + " has no room.");
    int old = students[si].getRoomNo();
    doVacate(si);
    cout << "  " << students[si].getName() << " vacated room " << old << ".\n";
}

void Hostel::transferStudent() {
    int sid = readInt("Student ID: ", 1, 999999);
    int si = findStudent(sid);
    if (si == -1) throw HostelException("Student not found.");
    if (!students[si].hasRoom()) throw HostelException("Student has no room to transfer from.");
    listVacantRooms();
    int rno = readInt("New room number: ", 1, 9999);
    int ri = findRoom(rno);
    if (ri == -1) throw HostelException("Room not found.");
    int old = students[si].getRoomNo();
    if (rno == old) throw HostelException("Student is already in that room.");
    if (rooms[ri].isFull()) throw HostelException("Room " + std::to_string(rno) + " is full.");
    doVacate(si);
    doAllocate(si, ri);
    cout << "  Moved " << students[si].getName() << " from room " << old << " to room " << rno << ".\n";
}

// ------------------------------------------------------------------ 7. REPORT
std::string Hostel::buildReport() const {
    std::ostringstream os;
    int beds = 0, used = 0, activeAllocs = 0, full = 0;
    double monthly = 0;
    for (int i = 0; i < roomCount; ++i) {
        const Room& r = rooms[i];
        beds += r.getCapacity();
        used += r.getOccupied();
        monthly += r.getOccupied() * r.getFee();
        if (r.isFull()) ++full;
    }
    for (int i = 0; i < allocCount; ++i)
        if (allocations[i].isActive()) ++activeAllocs;
    int unallocated = 0;
    for (int i = 0; i < studentCount; ++i)
        if (!students[i].hasRoom()) ++unallocated;

    os << "==================== " << name << " - OCCUPANCY REPORT ====================\n";
    os << "Date: " << today() << "\n\n";
    os << "Rooms            : " << roomCount << " (" << full << " full)\n";
    os << "Total beds       : " << beds << "\n";
    os << "Occupied beds    : " << used << "\n";
    os << "Vacant beds      : " << (beds - used) << "\n";
    os << "Occupancy        : " << std::fixed << std::setprecision(1) << (beds ? 100.0 * used / beds : 0.0) << "%\n";
    os << "Students         : " << studentCount << " (" << unallocated << " without a room)\n";
    os << "Wardens          : " << wardenCount << "\n";
    os << "Active allocations: " << activeAllocs << " of " << allocCount << " total\n";
    os << "Monthly fee income: " << std::setprecision(2) << monthly << "\n\n";

    os << "Room-wise residents:\n";
    for (int i = 0; i < roomCount; ++i) {
        const Room& r = rooms[i];
        os << "  Room " << std::setw(4) << r.getRoomNo() << " [" << r.getOccupied() << "/" << r.getCapacity() << "] ";
        bool any = false;
        for (int s = 0; s < studentCount; ++s)
            if (students[s].getRoomNo() == r.getRoomNo()) {
                os << (any ? ", " : "") << students[s].getName();
                any = true;
            }
        if (!any) os << "(empty)";
        os << "\n";
    }
    os << "\nStudents waiting for a room:\n";
    bool any = false;
    for (int i = 0; i < studentCount; ++i)
        if (!students[i].hasRoom()) {
            os << "  " << students[i].getId() << "  " << students[i].getName() << "\n";
            any = true;
        }
    if (!any) os << "  (none)\n";
    return os.str();
}

void Hostel::report() {
    std::string text = buildReport();
    cout << "\n" << text;
    try {
        fileManager.writeText("report.txt", text);
        cout << "\n  Report also saved to " << fileManager.getDir() << "/report.txt\n";
    } catch (const HostelException& e) {
        cout << "  Error: could not save report: " << e.what() << "\n";
    }
}

// ------------------------------------------------------------------ 8. SAVE / LOAD
void Hostel::saveLoadMenu() {
    cout << "\n--- SAVE / LOAD ---\n1. Save data to files\n2. Load data from files (discards unsaved changes)\n0. Back\n";
    int c = readInt("Choice: ", 0, 2);
    if (c == 1) saveData();
    else if (c == 2) {
        if (confirm("Reload from disk and discard unsaved changes?")) loadData();
        else cout << "  Cancelled.\n";
    }
}

void Hostel::saveData() {
    try {
        fileManager.saveAll(rooms, roomCount, students, studentCount, wardens, wardenCount, allocations, allocCount);
        cout << "  Saved " << roomCount << " rooms, " << studentCount << " students, " << wardenCount
             << " wardens, " << allocCount << " allocations to '" << fileManager.getDir() << "/'.\n";
    } catch (const HostelException& e) {
        cout << "  Error: save failed: " << e.what() << "\n";
    }
}

// Each loadXxx() reads one file; every line is turned into an object with fromString()
// (which validates it). Corrupt lines are skipped and counted.
int Hostel::loadRooms() {
    int n = 0, skipped = 0;
    std::string* lines = fileManager.readLines("rooms.txt", n);
    roomCount = 0;
    for (int i = 0; i < n; ++i) {
        try { Room r; r.fromString(lines[i]); addRoomObj(r); }
        catch (const HostelException&) { ++skipped; }
    }
    delete[] lines;
    return skipped;
}
int Hostel::loadStudents() {
    int n = 0, skipped = 0;
    std::string* lines = fileManager.readLines("students.txt", n);
    studentCount = 0;
    for (int i = 0; i < n; ++i) {
        try { Student st; st.fromString(lines[i]); addStudentObj(st); }
        catch (const HostelException&) { ++skipped; }
    }
    delete[] lines;
    return skipped;
}
int Hostel::loadWardens() {
    int n = 0, skipped = 0;
    std::string* lines = fileManager.readLines("wardens.txt", n);
    wardenCount = 0;
    for (int i = 0; i < n; ++i) {
        try { Warden w; w.fromString(lines[i]); addWardenObj(w); }
        catch (const HostelException&) { ++skipped; }
    }
    delete[] lines;
    return skipped;
}
int Hostel::loadAllocations() {
    int n = 0, skipped = 0;
    std::string* lines = fileManager.readLines("allocations.txt", n);
    allocCount = 0;
    for (int i = 0; i < n; ++i) {
        try { Allocation a; a.fromString(lines[i]); addAllocObj(a); }
        catch (const HostelException&) { ++skipped; }
    }
    delete[] lines;
    return skipped;
}

void Hostel::loadData() {
    int skipped = loadRooms() + loadStudents() + loadWardens() + loadAllocations();
    nextAllocId = 1;
    for (int i = 0; i < allocCount; ++i)
        if (allocations[i].getAllocId() >= nextAllocId) nextAllocId = allocations[i].getAllocId() + 1;
    cout << "  Loaded " << (roomCount + studentCount + wardenCount + allocCount) << " records (" << roomCount
         << " rooms, " << studentCount << " students, " << wardenCount << " wardens, " << allocCount
         << " allocations).\n";
    if (skipped > 0) cout << "  Warning: " << skipped << " corrupt line(s) were skipped.\n";
}
