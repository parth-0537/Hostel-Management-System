// Student.h - a hostel resident (derived from Person)
#ifndef STUDENT_H
#define STUDENT_H

#include "Person.h"

class Student : public Person {
    std::string course;
    int year;
    int roomNo;  // -1 when no room is allocated

public:
    Student();
    Student(int id, const std::string& name, const std::string& phone, const std::string& course,
            int year, int roomNo = -1);
    ~Student();

    const std::string& getCourse() const { return course; }
    int getYear() const { return year; }
    int getRoomNo() const { return roomNo; }
    bool hasRoom() const { return roomNo != -1; }

    void setCourse(const std::string& c);
    void setYear(int y);
    void setRoomNo(int r) { roomNo = r; }

    std::string getRole() const { return "Student"; }
    void display() const;
    std::string serialize() const;
    void fromString(const std::string& line);   // rebuilds this object from a file line
};

#endif
