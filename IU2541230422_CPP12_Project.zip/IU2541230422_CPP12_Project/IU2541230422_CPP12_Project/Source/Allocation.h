// Allocation.h - links one student to one room for a period of time
#ifndef ALLOCATION_H
#define ALLOCATION_H

#include <string>

class Allocation {
    int allocId;
    int studentId;
    int roomNo;
    std::string startDate;
    std::string endDate;  // "-" while the allocation is still active

public:
    Allocation();
    Allocation(int allocId, int studentId, int roomNo, const std::string& startDate,
               const std::string& endDate = "-");
    ~Allocation();

    int getAllocId() const { return allocId; }
    int getStudentId() const { return studentId; }
    int getRoomNo() const { return roomNo; }
    const std::string& getStartDate() const { return startDate; }
    const std::string& getEndDate() const { return endDate; }
    bool isActive() const { return endDate == "-"; }

    void close(const std::string& date);   // mark as vacated

    void display() const;
    std::string serialize() const;
    void fromString(const std::string& line);   // rebuilds this object from a file line
};

#endif
