// Utils.h - shared exception types and validated console-input helpers
#ifndef UTILS_H
#define UTILS_H

#include <exception>
#include <string>

// Thrown for any validation / business-rule / file-format error.
class HostelException : public std::exception {
    std::string message;

public:
    HostelException(const std::string& msg) : message(msg) {}
    const char* what() const noexcept { return message.c_str(); }
};

// Thrown when standard input is closed (EOF) so the program can save and exit cleanly.
class InputClosedException : public std::exception {
public:
    const char* what() const noexcept { return "Input closed"; }
};

// ---- validation ----
bool isValidName(const std::string& s);   // letters, spaces, . ' -  (max 40)
bool isValidPhone(const std::string& s);  // exactly 10 digits
bool isValidText(const std::string& s);   // non-empty, max 30, no '|'

// ---- parsing / string helpers ----
int splitLine(const std::string& line, char delim, std::string parts[], int maxParts);  // returns number of parts
int toInt(const std::string& s);          // throws HostelException on bad number
double toDouble(const std::string& s);    // throws HostelException on bad number
std::string toLower(const std::string& s);
std::string today();                      // YYYY-MM-DD

// ---- console input (re-prompts until valid) ----
std::string readLine(const std::string& prompt);
int readInt(const std::string& prompt, int minValue, int maxValue);
double readDouble(const std::string& prompt, double minValue, double maxValue);
bool confirm(const std::string& prompt);

#endif
