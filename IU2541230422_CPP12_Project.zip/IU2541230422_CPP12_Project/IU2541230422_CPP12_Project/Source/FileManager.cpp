// FileManager.cpp
#include "FileManager.h"

#include <cstdio>
#include <fstream>

FileManager::FileManager(const std::string& dataDir) : dir(dataDir) {}

FileManager::~FileManager() {}

std::string FileManager::pathOf(const std::string& file) const { return dir + "/" + file; }

void FileManager::writeText(const std::string& file, const std::string& text) const {
    std::string finalPath = pathOf(file);
    std::string tmpPath = finalPath + ".tmp";  // write to temp first so a crash cannot corrupt data
    {
        std::ofstream out(tmpPath.c_str());
        if (!out) throw HostelException("Cannot open '" + tmpPath + "' for writing (does the Data folder exist?).");
        out << text;
        out.flush();
        if (!out) throw HostelException("Write failed for '" + tmpPath + "'.");
    }
    std::remove(finalPath.c_str());   // Windows cannot rename over an existing file
    if (std::rename(tmpPath.c_str(), finalPath.c_str()) != 0)
        throw HostelException("Cannot replace '" + finalPath + "'.");
}

void FileManager::saveAll(const Room* rooms, int roomCount, const Student* students, int studentCount,
                          const Warden* wardens, int wardenCount, const Allocation* allocations,
                          int allocationCount) const {
    std::string text = "";
    for (int i = 0; i < roomCount; ++i) text += rooms[i].serialize() + "\n";
    writeText("rooms.txt", text);

    text = "";
    for (int i = 0; i < studentCount; ++i) text += students[i].serialize() + "\n";
    writeText("students.txt", text);

    text = "";
    for (int i = 0; i < wardenCount; ++i) text += wardens[i].serialize() + "\n";
    writeText("wardens.txt", text);

    text = "";
    for (int i = 0; i < allocationCount; ++i) text += allocations[i].serialize() + "\n";
    writeText("allocations.txt", text);
}

std::string* FileManager::readLines(const std::string& file, int& count) const {
    count = 0;
    std::string line;
    std::ifstream in(pathOf(file).c_str());
    if (!in) return new std::string[1];   // file missing -> no lines
    while (std::getline(in, line)) {
        if (!line.empty() && line[line.size() - 1] == '\r') line.erase(line.size() - 1);
        if (!line.empty()) ++count;
    }
    in.clear();
    in.seekg(0);
    std::string* lines = new std::string[count > 0 ? count : 1];   // dynamic memory
    int n = 0;
    while (n < count && std::getline(in, line)) {
        if (!line.empty() && line[line.size() - 1] == '\r') line.erase(line.size() - 1);
        if (!line.empty()) lines[n++] = line;
    }
    return lines;
}
