// Person.h - base class for Student and Warden
#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person {
protected:
    int id;
    std::string name;
    std::string phone;

public:
    Person();                                                     // default constructor
    Person(int id, const std::string& name, const std::string& phone);  // parameterized
    virtual ~Person();                                            // virtual destructor

    int getId() const { return id; }
    const std::string& getName() const { return name; }
    const std::string& getPhone() const { return phone; }

    void setId(int newId);                      // validated setters (throw HostelException)
    void setName(const std::string& newName);
    void setPhone(const std::string& newPhone);

    // Virtual functions: the version to call is chosen at run time (runtime polymorphism).
    // Student and Warden override them with their own versions.
    virtual std::string getRole() const;
    virtual void display() const;
    virtual std::string serialize() const;
};

#endif
