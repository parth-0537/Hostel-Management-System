// Person.cpp
#include "Person.h"

#include <iostream>
#include <sstream>

#include "Utils.h"

Person::Person() : id(0), name("Unknown"), phone("0000000000") {}

Person::Person(int pid, const std::string& pname, const std::string& pphone)
    : id(0), name("Unknown"), phone("0000000000") {
    setId(pid);
    setName(pname);
    setPhone(pphone);
}

Person::~Person() {}

void Person::setId(int newId) {
    if (newId <= 0 || newId > 999999) throw HostelException("ID must be between 1 and 999999.");
    id = newId;
}

void Person::setName(const std::string& newName) {
    if (!isValidName(newName))
        throw HostelException("Name must contain letters only (spaces . ' - allowed), max 40 chars.");
    name = newName;
}

void Person::setPhone(const std::string& newPhone) {
    if (!isValidPhone(newPhone)) throw HostelException("Phone must be exactly 10 digits.");
    phone = newPhone;
}

std::string Person::getRole() const { return "Person"; }

void Person::display() const {
    std::cout << "Person " << id << "  " << name << "  " << phone << "\n";
}

std::string Person::serialize() const {
    std::ostringstream os;
    os << id << '|' << name << '|' << phone;
    return os.str();
}
