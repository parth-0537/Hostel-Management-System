// main.cpp - creates the system object, shows the menu and delegates to Hostel
#include <iostream>

#include "Hostel.h"
#include "Utils.h"

void showMenu(const std::string& hostelName) {
    std::cout << "\n=========================================\n"
              << "   " << hostelName << "\n"
              << "   Hostel Room Allocation System\n"
              << "=========================================\n"
              << " 1. Add Record\n"
              << " 2. Display Records\n"
              << " 3. Search Record\n"
              << " 4. Update Record\n"
              << " 5. Delete Record\n"
              << " 6. Room Allocation (Main Transaction)\n"
              << " 7. Report\n"
              << " 8. Save/Load\n"
              << " 9. Exit\n"
              << "-----------------------------------------\n";
}

int main(int argc, char* argv[]) {
    std::string dataDir = (argc > 1) ? argv[1] : "Data";
    Hostel hostel("University Hostel", dataDir);

    std::cout << "Starting up...\n";
    hostel.loadData();   // START -> load existing records

    try {
        bool running = true;
        while (running) {
            showMenu(hostel.getName());
            int choice = readInt("Enter choice (1-9): ", 1, 9);
            switch (choice) {
                case 1: hostel.addRecord(); break;
                case 2: hostel.displayRecords(); break;
                case 3: hostel.searchRecord(); break;
                case 4: hostel.updateRecord(); break;
                case 5: hostel.deleteRecord(); break;
                case 6: hostel.mainTransaction(); break;
                case 7: hostel.report(); break;
                case 8: hostel.saveLoadMenu(); break;
                case 9: running = false; break;
            }
        }
    } catch (const InputClosedException&) {
        std::cout << "\nInput closed - saving and exiting.\n";
    }

    hostel.saveData();   // perform operations -> save updated records -> EXIT
    std::cout << "Goodbye!\n";
    return 0;
}
