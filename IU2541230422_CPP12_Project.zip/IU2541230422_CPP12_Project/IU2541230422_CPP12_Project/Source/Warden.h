// Warden.h - hostel staff member in charge of a block (derived from Person)
#ifndef WARDEN_H
#define WARDEN_H

#include "Person.h"

class Warden : public Person {
    std::string block;  // e.g. "A"
    std::string shift;  // Day / Evening / Night

public:
    Warden();
    Warden(int id, const std::string& name, const std::string& phone, const std::string& block,
           const std::string& shift);
    ~Warden();

    const std::string& getBlock() const { return block; }
    const std::string& getShift() const { return shift; }
    void setBlock(const std::string& b);
    void setShift(const std::string& s);

    std::string getRole() const { return "Warden"; }
    void display() const;
    std::string serialize() const;
    void fromString(const std::string& line);   // rebuilds this object from a file line
};

#endif
