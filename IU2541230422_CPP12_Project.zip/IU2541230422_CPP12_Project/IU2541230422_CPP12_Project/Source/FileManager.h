// FileManager.h - all disk persistence (pipe-delimited text files in the data folder)
#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <string>

#include "Allocation.h"
#include "Utils.h"
#include "Room.h"
#include "Student.h"
#include "Warden.h"

class FileManager {
    std::string dir;

    std::string pathOf(const std::string& file) const;

public:
    FileManager(const std::string& dataDir = "Data");
    ~FileManager();

    const std::string& getDir() const { return dir; }

    // Writes rooms.txt, students.txt, wardens.txt, allocations.txt
    void saveAll(const Room* rooms, int roomCount, const Student* students, int studentCount,
                 const Warden* wardens, int wardenCount, const Allocation* allocations,
                 int allocationCount) const;

    // Reads the non-empty lines of a file into a new[] array of strings and sets 'count'.
    // A missing file gives count = 0 (first run). The CALLER must delete[] the returned array.
    std::string* readLines(const std::string& file, int& count) const;

    void writeText(const std::string& file, const std::string& text) const;
};

#endif
