// Student.cpp
#include "Student.h"

#include <iomanip>
#include <iostream>
#include <sstream>

#include "Utils.h"

Student::Student() : Person(), course("Undeclared"), year(1), roomNo(-1) {}

Student::Student(int sid, const std::string& sname, const std::string& sphone,
                 const std::string& scourse, int syear, int sroom)
    : Person(sid, sname, sphone), course("Undeclared"), year(1), roomNo(sroom) {
    setCourse(scourse);
    setYear(syear);
}

Student::~Student() {}

void Student::setCourse(const std::string& c) {
    if (!isValidText(c)) throw HostelException("Course must be 1-30 characters and cannot contain '|'.");
    course = c;
}

void Student::setYear(int y) {
    if (y < 1 || y > 6) throw HostelException("Year must be between 1 and 6.");
    year = y;
}

void Student::display() const {
    std::cout << std::left << std::setw(9) << "Student" << std::setw(8) << id << std::setw(22) << name
              << std::setw(13) << phone << std::setw(14) << course << "Yr " << year << "   Room: ";
    if (hasRoom()) std::cout << roomNo;
    else std::cout << "-";
    std::cout << "\n";
}

std::string Student::serialize() const {
    std::ostringstream os;
    os << id << '|' << name << '|' << phone << '|' << course << '|' << year << '|' << roomNo;
    return os.str();
}

void Student::fromString(const std::string& line) {
    std::string f[7];
    if (splitLine(line, '|', f, 6) != 6) throw HostelException("Malformed student record: " + line);
    *this = Student(toInt(f[0]), f[1], f[2], f[3], toInt(f[4]), toInt(f[5]));
}
