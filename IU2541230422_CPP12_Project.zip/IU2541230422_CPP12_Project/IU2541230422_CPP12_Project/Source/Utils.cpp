// Utils.cpp
#include "Utils.h"

#include <cctype>
#include <ctime>
#include <iostream>
#include <sstream>

bool isValidName(const std::string& s) {
    if (s.empty() || s.size() > 40) return false;
    bool hasLetter = false;
    for (unsigned int i = 0; i < s.size(); ++i) {
        unsigned char c = static_cast<unsigned char>(s[i]);
        if (std::isalpha(c)) hasLetter = true;
        else if (c != ' ' && c != '.' && c != '\'' && c != '-') return false;
    }
    return hasLetter;
}

bool isValidPhone(const std::string& s) {
    if (s.size() != 10) return false;
    for (unsigned int i = 0; i < s.size(); ++i)
        if (!std::isdigit(static_cast<unsigned char>(s[i]))) return false;
    return true;
}

bool isValidText(const std::string& s) {
    return !s.empty() && s.size() <= 30 && s.find('|') == std::string::npos;
}

int splitLine(const std::string& line, char delim, std::string parts[], int maxParts) {
    int count = 0;
    std::string item = "";
    for (unsigned int i = 0; i <= line.size(); ++i) {
        if (i == line.size() || line[i] == delim) {
            if (count >= maxParts) return maxParts + 1;   // too many fields
            parts[count++] = item;
            item = "";
        } else {
            item += line[i];
        }
    }
    return count;
}

int toInt(const std::string& s) {
    try {
        size_t pos = 0;
        int v = std::stoi(s, &pos);
        if (pos != s.size()) throw HostelException("Invalid integer: '" + s + "'");
        return v;
    } catch (const HostelException&) {
        throw;
    } catch (const std::exception&) {
        throw HostelException("Invalid integer: '" + s + "'");
    }
}

double toDouble(const std::string& s) {
    try {
        size_t pos = 0;
        double v = std::stod(s, &pos);
        if (pos != s.size()) throw HostelException("Invalid number: '" + s + "'");
        return v;
    } catch (const HostelException&) {
        throw;
    } catch (const std::exception&) {
        throw HostelException("Invalid number: '" + s + "'");
    }
}

std::string toLower(const std::string& s) {
    std::string r = s;
    for (unsigned int i = 0; i < r.size(); ++i) r[i] = static_cast<char>(std::tolower(static_cast<unsigned char>(r[i])));
    return r;
}

std::string today() {
    std::time_t t = std::time(0);
    char buf[16];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d", std::localtime(&t));
    return buf;
}

std::string readLine(const std::string& prompt) {
    std::cout << prompt << std::flush;
    std::string line;
    if (!std::getline(std::cin, line)) throw InputClosedException();
    // trim whitespace
    size_t b = line.find_first_not_of(" \t\r");
    size_t e = line.find_last_not_of(" \t\r");
    line = (b == std::string::npos) ? "" : line.substr(b, e - b + 1);
    return line;
}

int readInt(const std::string& prompt, int minValue, int maxValue) {
    while (true) {
        std::string line = readLine(prompt);
        try {
            int v = toInt(line);
            if (v < minValue || v > maxValue) {
                std::cout << "  ! Enter a number between " << minValue << " and " << maxValue << ".\n";
                continue;
            }
            return v;
        } catch (const HostelException&) {
            std::cout << "  ! Invalid input. Please enter a whole number.\n";
        }
    }
}

double readDouble(const std::string& prompt, double minValue, double maxValue) {
    while (true) {
        std::string line = readLine(prompt);
        try {
            double v = toDouble(line);
            if (v < minValue || v > maxValue) {
                std::cout << "  ! Enter a value between " << minValue << " and " << maxValue << ".\n";
                continue;
            }
            return v;
        } catch (const HostelException&) {
            std::cout << "  ! Invalid input. Please enter a number.\n";
        }
    }
}

bool confirm(const std::string& prompt) {
    while (true) {
        std::string a = toLower(readLine(prompt + " (y/n): "));
        if (a == "y" || a == "yes") return true;
        if (a == "n" || a == "no") return false;
        std::cout << "  ! Please answer y or n.\n";
    }
}


