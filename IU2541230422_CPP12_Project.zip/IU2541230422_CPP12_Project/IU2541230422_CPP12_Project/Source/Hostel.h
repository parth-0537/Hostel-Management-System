// Hostel.h - the "system" class: owns all records and implements every menu operation
#ifndef HOSTEL_H
#define HOSTEL_H

#include <string>

#include "Allocation.h"
#include "FileManager.h"
#include "Room.h"
#include "Student.h"
#include "Warden.h"

class Hostel {
    std::string name;
    FileManager fileManager;
    // Dynamic arrays (allocated with new[], released with delete[])
    Room* rooms;              int roomCount;       int roomCap;
    Student* students;        int studentCount;    int studentCap;
    Warden* wardens;          int wardenCount;     int wardenCap;
    Allocation* allocations;  int allocCount;      int allocCap;
    int nextAllocId;

    Hostel(const Hostel&);              // copying is disabled (class owns raw memory)
    Hostel& operator=(const Hostel&);

    // array helpers: add (doubling the array when full) and remove
    void addRoomObj(const Room& r);
    void addStudentObj(const Student& s);
    void addWardenObj(const Warden& w);
    void addAllocObj(const Allocation& a);
    void removeRoomAt(int index);
    void removeStudentAt(int index);
    void removeWardenAt(int index);

    // lookups (return -1 when not found)
    int findRoom(int roomNo) const;
    int findStudent(int id) const;
    int findWarden(int id) const;
    int findActiveAllocation(int studentId) const;
    bool idInUse(int id) const;   // student & warden IDs share one ID space
    int loadRooms();   int loadStudents();   int loadWardens();   int loadAllocations();   // return skipped lines

    // add
    void addRoom();
    void addStudent();
    void addWarden();
    // display
    void displayRooms() const;
    void displayStudents() const;
    void displayWardens() const;
    void displayAllocations() const;
    void displayAllPeople() const;   // runtime polymorphism through Person*
    // search / update / delete
    void searchRoom() const;
    void searchStudentById() const;
    void searchStudentByName() const;
    void searchWarden() const;
    void updateRoom();
    void updateStudent();
    void updateWarden();
    void deleteRoom();
    void deleteStudent();
    void deleteWarden();
    // main transaction
    void allocateRoom();
    void vacateRoom();
    void transferStudent();
    void doAllocate(int studentIdx, int roomIdx);   // shared core of allocate/transfer
    void doVacate(int studentIdx);                  // shared core of vacate/delete/transfer
    void listVacantRooms() const;
    std::string buildReport() const;

public:
    Hostel(const std::string& hostelName, const std::string& dataDir = "Data");
    ~Hostel();

    // Menu operations (called from main)
    void addRecord();
    void displayRecords();
    void searchRecord();
    void updateRecord();
    void deleteRecord();
    void mainTransaction();   // allocate / vacate / transfer rooms
    void report();
    void saveLoadMenu();

    // Persistence
    void saveData();
    void loadData();

    const std::string& getName() const { return name; }
};

#endif
